import type { NextApiRequest, NextApiResponse } from "next";
import { getClientIp } from "request-ip";
import LRU from "lru-cache";

const rateLimitStore = new LRU<string, { count: number; timestamp: number }>({
  max: 5000,
  ttl: 1000 * 60 * 10, // 10 minutes
});
const MAX_REQUESTS = 20;
const WINDOW_MS = 60 * 1000; // 1 minute

export default function handler(req: NextApiRequest, res: NextApiResponse) {
  const ip = getClientIp(req) || "unknown";
  const now = Date.now();
  const record = rateLimitStore.get(ip) || { count: 0, timestamp: now };
  if (now - record.timestamp > WINDOW_MS) {
    rateLimitStore.set(ip, { count: 1, timestamp: now });
    return res.status(200).json({ allowed: true });
  }
  if (record.count >= MAX_REQUESTS) {
    return res.status(429).json({ error: "Too many requests" });
  }
  rateLimitStore.set(ip, { count: record.count + 1, timestamp: record.timestamp });
  res.status(200).json({ allowed: true });
}